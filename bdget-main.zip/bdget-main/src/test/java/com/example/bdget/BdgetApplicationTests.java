package com.example.bdget;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdgetApplicationTests {

        @Test
        void contextLoads() {
                BdgetApplication.main(new String[]{});
        }

}
