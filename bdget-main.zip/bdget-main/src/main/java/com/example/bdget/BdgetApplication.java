package com.example.bdget;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdgetApplication {

	public static void main(String[] args) {
		SpringApplication.run(BdgetApplication.class, args);
	}

}
